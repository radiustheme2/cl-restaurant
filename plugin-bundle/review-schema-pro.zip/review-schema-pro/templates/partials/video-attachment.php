<?php
/**
 * Review video items (Pro).
 *
 * Moved from the free attachment partial. Loaded by VideoReview::render() on
 * `rtrs_review_attachment_media`; override in a theme as
 * `review-schema/partials/video-attachment.php`.
 *
 * @author      RadiusTheme
 * @package     review-schema-pro/templates
 * @version     1.0.0
 *
 * @var array $rtrs_videos     Video attachment IDs (hosted) or URLs (external).
 * @var bool  $rtrs_self_video Whether the videos are hosted uploads.
 */

use Rtrs\Helpers\Functions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

foreach ( (array) $rtrs_videos as $rtrs_video ) {
	$rtrs_youtube_video_id = '';
	if ( ! $rtrs_self_video ) {
		$rtrs_pattern = '#^(?:https?://)?(?:www\.)?(?:youtu\.be/|youtube\.com(?:/embed/|/v/|/watch\?v=|/watch\?.+&v=))([\w-]{11})(?:.+)?$#x';
		preg_match( $rtrs_pattern, (string) $rtrs_video, $rtrs_matches );
		$rtrs_youtube_video_id = isset( $rtrs_matches[1] ) ? $rtrs_matches[1] : '';
	}

	$rtrs_image_url = $rtrs_self_video ? Functions::get_default_placeholder_url() : 'https://img.youtube.com/vi/' . $rtrs_youtube_video_id . '/default.jpg';
	$rtrs_video_url = $rtrs_self_video ? '' : 'https://www.youtube.com/embed/' . $rtrs_youtube_video_id;
	?>
	<div class="rtrs-media-item rtrs-media-video">
		<img src="<?php echo esc_url( $rtrs_image_url ); ?>" style="width: 80px;" alt="<?php esc_attr_e( 'SchemaEngine AI', 'review-schema-pro' ); ?>">
		<?php if ( ! $rtrs_self_video ) { ?>
			<a href="<?php echo esc_url( $rtrs_video_url ); ?>?rel=0&amp;autoplay=1" data-featherlight="iframe" data-featherlight-variant="rtrs-lightbox" data-featherlight-iframe-width="640" data-featherlight-iframe-height="480" data-featherlight-iframe-frameborder="0" data-featherlight-iframe-allow="autoplay; encrypted-media" data-featherlight-iframe-allowfullscreen="true" class="rtrs-video-icon"><i class="rtrs-play"></i></a>
		<?php } else { ?>
			<?php // Pass the attachment ID, not the URL: the popup handler resolves the URL itself. ?>
			<a href="#" data-attachment-id="<?php echo absint( $rtrs_video ); ?>" class="rtrs-video-icon rtrs-play-self-video"><i class="rtrs-play"></i></a>
		<?php } ?>
	</div>
	<?php
}
