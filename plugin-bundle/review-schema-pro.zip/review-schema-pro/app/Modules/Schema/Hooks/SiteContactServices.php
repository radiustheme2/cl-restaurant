<?php
/**
 * Site ContactPoint and Services rows beyond the first (Pro).
 *
 * The free plugin outputs the first ContactPoint row and the first Service row
 * of Site Info; "+ Add New" rows are Pro. Moved from the free site schema
 * builder: same sanitizing, same JSON-LD shape and key order.
 *
 * @package Rtrsp\Modules\Schema\Hooks
 */

namespace Rtrsp\Modules\Schema\Hooks;

use Rtrs\Helpers\Functions;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SiteContactServices
 */
class SiteContactServices {

	use SingletonTrait;

	/**
	 * Free version that outputs only the first row itself.
	 */
	const MIN_FREE_VERSION = '3.1.4';

	/**
	 * Register hooks. An older free plugin still outputs every row, so stay out.
	 *
	 * @return void
	 */
	public function init() {
		if ( ! defined( 'RTRS_VERSION' ) || version_compare( RTRS_VERSION, self::MIN_FREE_VERSION, '<' ) ) {
			return;
		}
		add_filter( 'rtseo_local_business_and_organization_schema', [ $this, 'add_rows' ] );
	}

	/**
	 * Append ContactPoint and Service rows 2+ to the site schema node.
	 *
	 * @param array $node Site LocalBusiness / Organization node built by free.
	 * @return array
	 */
	public function add_rows( $node ) {
		if ( ! is_array( $node ) ) {
			return $node;
		}
		$meta = get_option( 'rtrs_schema_settings' );
		if ( ! is_array( $meta ) ) {
			return $node;
		}
		$helper = new Functions();

		$points = isset( $node['contactPoint'] ) && is_array( $node['contactPoint'] ) ? $node['contactPoint'] : [];
		$extra  = ! empty( $meta['contactPoint'] ) && is_array( $meta['contactPoint'] ) ? array_slice( $meta['contactPoint'], 1 ) : [];
		foreach ( $extra as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$data = [];
			if ( ! empty( $point['telephone'] ) ) {
				$data['telephone'] = $helper->sanitizeOutPut( $point['telephone'] );
			}
			if ( ! empty( $point['contactType'] ) ) {
				$data['contactType'] = $helper->sanitizeOutPut( $point['contactType'] );
			}
			if ( ! empty( $point['areaServed'] ) ) {
				$data['areaServed'] = $helper->sanitizeOutPut( $point['areaServed'] );
			}
			if ( ! empty( $point['language'] ) ) {
				$data['availableLanguage'] = array_map( 'trim', explode( ',', $helper->sanitizeOutPut( $point['language'] ) ) );
			}
			if ( $data ) {
				$points[] = [ '@type' => 'ContactPoint' ] + $data;
			}
		}

		$catalog = isset( $node['hasOfferCatalog'] ) && is_array( $node['hasOfferCatalog'] ) ? $node['hasOfferCatalog'] : null;
		$items   = [];
		if ( 'Person' !== ( $meta['site_category'] ?? '' ) && ! empty( $meta['offer_catalog'] ) && is_array( $meta['offer_catalog'] ) ) {
			foreach ( array_slice( $meta['offer_catalog'], 1 ) as $offer ) {
				$name = is_array( $offer ) && ! empty( $offer['name'] ) ? $helper->sanitizeOutPut( $offer['name'] ) : '';
				if ( $name ) {
					$items[] = [
						'@type'       => 'Offer',
						'itemOffered' => [
							'@type' => 'Service',
							'name'  => $name,
						],
					];
				}
			}
		}
		if ( $items ) {
			if ( ! $catalog ) {
				$catalog = [
					'@type'           => 'OfferCatalog',
					'name'            => ! empty( $meta['offer_catalog_name'] ) ? $helper->sanitizeOutPut( $meta['offer_catalog_name'] ) : esc_html__( 'Services', 'review-schema-pro' ),
					'itemListElement' => [],
				];
			}
			$catalog['itemListElement'] = array_merge( isset( $catalog['itemListElement'] ) && is_array( $catalog['itemListElement'] ) ? $catalog['itemListElement'] : [], $items );
		}

		// Both keys are the last ones free sets: re-add them in that order.
		unset( $node['contactPoint'], $node['hasOfferCatalog'] );
		if ( $points ) {
			$node['contactPoint'] = $points;
		}
		if ( $catalog ) {
			$node['hasOfferCatalog'] = $catalog;
		}

		return $node;
	}
}
