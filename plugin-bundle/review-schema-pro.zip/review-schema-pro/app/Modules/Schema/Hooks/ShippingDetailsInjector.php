<?php
/**
 * Dynamic ShippingDetails Injector (Pro).
 *
 * Injects shippingDetails and hasMerchantReturnPolicy references into
 * Product/ProductGroup offers at render time when the saved schema is
 * missing them. Finds existing global OfferShippingDetails and
 * MerchantReturnPolicy nodes in the graph and links them to offers.
 *
 * If no global nodes exist, builds them from ecommerce settings.
 *
 * @package Rtrsp\Modules\Schema\Hooks
 * @since   1.2.0
 */

namespace Rtrsp\Modules\Schema\Hooks;

use Rtrsp\Helpers\FnsPro;
use Rtrsp\Traits\SingletonTrait;

class ShippingDetailsInjector {

	use SingletonTrait;

	/**
	 * Initialize hooks.
	 */
	public function init() {
		add_filter( 'rtrs_ai_schema_before_render', [ $this, 'add_global_offer_nodes' ], 5, 2 );
		add_filter( 'rtrs_ai_schema_before_render', [ $this, 'inject_shipping_details' ], 10, 2 );
	}

	/**
	 * Add MerchantReturnPolicy and OfferShippingDetails global nodes for Product pages.
	 *
	 * Moved from the free SchemaRenderer::build_global_schemas(). Runs before
	 * inject_shipping_details() so offers link to these nodes; a node whose
	 * @id is already in the graph is not added twice.
	 *
	 * @param array $schemas Full schema graph (content + global).
	 * @param int   $post_id Current post ID (unused).
	 * @return array
	 */
	public function add_global_offer_nodes( $schemas, $post_id = 0 ) {
		if ( empty( $schemas ) || ! is_array( $schemas ) ) {
			return $schemas;
		}

		$has_product = false;
		$ids         = [];
		foreach ( $schemas as $node ) {
			$type = is_array( $node ) ? ( $node['@type'] ?? '' ) : '';
			if ( in_array( $type, [ 'Product', 'ProductGroup' ], true ) ) {
				$has_product = true;
			}
			if ( is_array( $node ) && ! empty( $node['@id'] ) && is_string( $node['@id'] ) ) {
				$ids[ $node['@id'] ] = true;
			}
		}
		if ( ! $has_product ) {
			return $schemas;
		}

		$return_policy = FnsPro::get_merchant_return_policy();
		if ( ! empty( $return_policy ) && empty( $ids[ $return_policy['@id'] ?? '' ] ) ) {
			$schemas[] = $return_policy;
		}

		$currency = 'USD';
		if ( function_exists( 'get_woocommerce_currency' ) ) {
			$currency = get_woocommerce_currency();
		} elseif ( class_exists( 'FluentCart\Api\CurrencySettings' ) ) {
			$currency = \FluentCart\Api\CurrencySettings::get( 'currency' ) ?: 'USD';
		}
		$shipping_details = FnsPro::get_offer_shipping_details( $currency );
		if ( ! empty( $shipping_details ) ) {
			foreach ( $shipping_details as $sd ) {
				if ( empty( $ids[ $sd['@id'] ?? '' ] ) ) {
					$schemas[] = $sd;
				}
			}
		}

		return $schemas;
	}

	/**
	 * Inject shippingDetails and hasMerchantReturnPolicy into Product offers.
	 *
	 * @param array $schemas Full schema graph (content + global).
	 * @param int   $post_id Current post ID.
	 * @return array Modified schema graph.
	 */
	public function inject_shipping_details( $schemas, $post_id ) {
		if ( empty( $schemas ) || ! is_array( $schemas ) ) {
			return $schemas;
		}

		// Password-protected: no offers are public, so no shipping / return nodes either.
		if ( FnsPro::is_schema_protected( $post_id ) ) {
			return $schemas;
		}

		// Check if any Product/ProductGroup exists.
		$has_product = false;
		foreach ( $schemas as $node ) {
			$type = $node['@type'] ?? '';
			if ( in_array( $type, [ 'Product', 'ProductGroup' ], true ) ) {
				$has_product = true;
				break;
			}
		}

		if ( ! $has_product ) {
			return $schemas;
		}

		// Collect existing @id references from global nodes in the graph.
		$shipping_refs     = [];
		$return_policy_ref = null;

		foreach ( $schemas as $node ) {
			$type = $node['@type'] ?? '';

			if ( 'OfferShippingDetails' === $type && ! empty( $node['@id'] ) ) {
				$shipping_refs[] = [ '@id' => $node['@id'] ];
			}

			if ( 'MerchantReturnPolicy' === $type && ! empty( $node['@id'] ) ) {
				$return_policy_ref = [ '@id' => $node['@id'] ];
			}
		}

		// If no global OfferShippingDetails exist, build from settings.
		if ( empty( $shipping_refs ) ) {
			$currency = 'USD';
			if ( function_exists( 'get_woocommerce_currency' ) ) {
				$currency = get_woocommerce_currency();
			} elseif ( class_exists( 'FluentCart\Api\CurrencySettings' ) ) {
				$currency = \FluentCart\Api\CurrencySettings::get( 'currency' ) ?: 'USD';
			}

			$built = FnsPro::get_offer_shipping_details( $currency );

			// If WC zones returned nothing, build a simple fallback from base country.
			if ( empty( $built ) ) {
				$built = $this->build_fallback_shipping( $currency );
			}

			if ( ! empty( $built ) ) {
				foreach ( $built as $sd ) {
					$schemas[]       = $sd;
					$shipping_refs[] = [ '@id' => $sd['@id'] ];
				}
			}
		}

		// If no global MerchantReturnPolicy exists, build from settings.
		if ( empty( $return_policy_ref ) ) {
			$built_policy = FnsPro::get_merchant_return_policy();
			if ( ! empty( $built_policy ) && ! empty( $built_policy['@id'] ) ) {
				$schemas[]         = $built_policy;
				$return_policy_ref = [ '@id' => $built_policy['@id'] ];
			}
		}

		if ( empty( $shipping_refs ) && empty( $return_policy_ref ) ) {
			return $schemas;
		}

		// Inject references into Product/ProductGroup offers.
		foreach ( $schemas as &$schema ) {
			$type = $schema['@type'] ?? '';

			if ( ! in_array( $type, [ 'Product', 'ProductGroup' ], true ) ) {
				continue;
			}

			if ( empty( $schema['offers'] ) || ! is_array( $schema['offers'] ) ) {
				continue;
			}

			$this->inject_into_offers( $schema['offers'], $shipping_refs, $return_policy_ref );
		}
		unset( $schema );

		return $schemas;
	}

	/**
	 * Inject shipping and return policy into an offers structure.
	 *
	 * Handles all offer formats:
	 * - Single Offer: {"@type": "Offer", ...}
	 * - AggregateOffer with nested offers: {"@type": "AggregateOffer", "offers": [...]}
	 * - Array of Offer objects: [{"@type": "Offer"}, ...]
	 *
	 * @param array      $offers            Offers data (by reference).
	 * @param array      $shipping_refs     Array of @id references.
	 * @param array|null $return_policy_ref Single @id reference.
	 */
	private function inject_into_offers( &$offers, $shipping_refs, $return_policy_ref ) {
		$offer_type = $offers['@type'] ?? '';

		if ( 'AggregateOffer' === $offer_type ) {
			$this->inject_into_single_offer( $offers, $shipping_refs, $return_policy_ref );

			// Also inject into nested offers inside AggregateOffer.
			if ( ! empty( $offers['offers'] ) && is_array( $offers['offers'] ) ) {
				foreach ( $offers['offers'] as &$nested ) {
					if ( is_array( $nested ) ) {
						$this->inject_into_single_offer( $nested, $shipping_refs, $return_policy_ref );
					}
				}
				unset( $nested );
			}

			return;
		}

		if ( 'Offer' === $offer_type ) {
			$this->inject_into_single_offer( $offers, $shipping_refs, $return_policy_ref );

			return;
		}

		// Array of Offer/AggregateOffer objects.
		if ( isset( $offers[0] ) ) {
			foreach ( $offers as &$offer ) {
				if ( ! is_array( $offer ) ) {
					continue;
				}
				$this->inject_into_offers( $offer, $shipping_refs, $return_policy_ref );
			}
			unset( $offer );
		}
	}

	/**
	 * Inject shipping and return policy references into a single offer.
	 *
	 * @param array      $offer             Offer schema (by reference).
	 * @param array      $shipping_refs     Array of @id references.
	 * @param array|null $return_policy_ref Single @id reference.
	 */
	private function inject_into_single_offer( &$offer, $shipping_refs, $return_policy_ref ) {
		if ( ! empty( $shipping_refs ) && empty( $offer['shippingDetails'] ) ) {
			$offer['shippingDetails'] = $shipping_refs;
		}

		if ( ! empty( $return_policy_ref ) && empty( $offer['hasMerchantReturnPolicy'] ) ) {
			$offer['hasMerchantReturnPolicy'] = $return_policy_ref;
		}
	}

	/**
	 * Build a simple fallback OfferShippingDetails from WC base country.
	 *
	 * Used when WC shipping zones return nothing.
	 *
	 * @param string $currency Currency code.
	 * @return array Array of OfferShippingDetails schema nodes.
	 */
	private function build_fallback_shipping( $currency ) {
		$settings = get_option( 'rtrs_schema_ecommerce_settings', [] );
		$country  = $settings['return_policy_country'] ?? '';

		if ( empty( $country ) && function_exists( 'WC' ) && WC()->countries ) {
			$country = WC()->countries->get_base_country();
		}

		if ( empty( $country ) ) {
			return [];
		}

		$handling_min = isset( $settings['handling_time_min'] ) && '' !== $settings['handling_time_min']
			? absint( $settings['handling_time_min'] ) : 0;
		$handling_max = isset( $settings['handling_time_max'] ) && '' !== $settings['handling_time_max']
			? absint( $settings['handling_time_max'] ) : 1;
		$transit_min  = isset( $settings['transit_time_min'] ) && '' !== $settings['transit_time_min']
			? absint( $settings['transit_time_min'] ) : 3;
		$transit_max  = isset( $settings['transit_time_max'] ) && '' !== $settings['transit_time_max']
			? absint( $settings['transit_time_max'] ) : 7;

		return [
			[
				'@type'               => 'OfferShippingDetails',
				'@id'                 => home_url( '#StandardShipping-0' ),
				'shippingRate'        => [
					'@type'    => 'MonetaryAmount',
					'value'    => 0,
					'currency' => $currency,
				],
				'shippingDestination' => [
					'@type'          => 'DefinedRegion',
					'addressCountry' => strtoupper( $country ),
				],
				'deliveryTime'        => [
					'@type'        => 'ShippingDeliveryTime',
					'handlingTime' => [
						'@type'    => 'QuantitativeValue',
						'minValue' => $handling_min,
						'maxValue' => $handling_max,
						'unitCode' => 'DAY',
					],
					'transitTime'  => [
						'@type'    => 'QuantitativeValue',
						'minValue' => $transit_min,
						'maxValue' => $transit_max,
						'unitCode' => 'DAY',
					],
				],
			],
		];
	}
}
