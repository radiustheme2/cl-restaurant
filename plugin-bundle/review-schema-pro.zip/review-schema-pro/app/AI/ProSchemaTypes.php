<?php
/**
 * Pro Schema Types - Templates and validation for pro-gated schema types.
 *
 * Provides AI prompt templates and validation for: Book, JobPosting, Recipe,
 * LocalBusiness, Restaurant, Product, ProductGroup, Course.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\SchemaValidator;

defined( 'ABSPATH' ) || exit;

class ProSchemaTypes {

	/**
	 * Provide AI prompt templates for pro-gated schema types.
	 *
	 * Hooked to `rtrs_ai_type_template` filter.
	 *
	 * @param string $template    Existing template.
	 * @param string $type        Schema type name.
	 * @param string $entity_type Entity type (Organization/Person).
	 *
	 * @return string Template string.
	 */
	public static function get_type_template( $template, $type, $entity_type ) {
		if ( '' !== $template ) {
			return $template;
		}

		switch ( $type ) {
			case 'Recipe':
				return self::get_recipe_template();

			case 'LocalBusiness':
			case 'Restaurant':
				return self::get_local_business_template();

			case 'Book':
				return self::get_book_template();

			case 'JobPosting':
				return self::get_job_posting_template();
		}

		return $template;
	}

	/**
	 * Validate pro-gated schema types.
	 *
	 * Hooked to `rtrs_ai_validate_schema_type` action.
	 *
	 * @param string          $type      Schema @type.
	 * @param array           $schema    Schema data.
	 * @param string          $prefix    Error prefix.
	 * @param SchemaValidator $validator Validator instance.
	 */
	public static function validate_schema_type( $type, $schema, $prefix, $validator ) {
		switch ( $type ) {
			case 'Product':
				self::validate_product( $schema, $prefix, $validator );
				break;

			case 'ProductGroup':
				self::validate_productgroup( $schema, $prefix, $validator );
				break;

			case 'Recipe':
				self::validate_recipe( $schema, $prefix, $validator );
				break;

			case 'Course':
				self::validate_course( $schema, $prefix, $validator );
				break;

			case 'LocalBusiness':
			case 'Restaurant':
				self::validate_localbusiness( $schema, $prefix, $validator );
				break;

			case 'TouristAttraction':
				self::validate_touristattraction( $schema, $prefix, $validator );
				break;
		}
	}

	// -------------------------------------------------------------------------
	// Templates
	// -------------------------------------------------------------------------

	private static function get_recipe_template() {
		return <<<TPL
Required fields for Recipe:
- name, description, image
- recipeIngredient (array of strings)
- recipeInstructions (array of HowToStep)
- prepTime, cookTime, totalTime (ISO 8601 duration)
- recipeYield, recipeCategory, recipeCuisine
- author, datePublished
TPL;
	}

	private static function get_local_business_template() {
		return <<<TPL
Required fields for LocalBusiness:
- name, description, image
- address (PostalAddress)
- telephone, email (if available)
- openingHours (if available)
- geo (latitude, longitude if available)
- priceRange (if determinable)
TPL;
	}

	private static function get_book_template() {
		return <<<TPL
Required fields for Book:
- name, description, image
- author (Person)
- isbn (if available)
- numberOfPages (if available)
- publisher, datePublished
TPL;
	}

	private static function get_job_posting_template() {
		return <<<TPL
Required fields for JobPosting:
- title, description
- datePosted, validThrough
- hiringOrganization (Organization with name)
- jobLocation (Place with address)
- employmentType (if available)
- baseSalary (if available)
TPL;
	}

	// -------------------------------------------------------------------------
	// Validators
	// -------------------------------------------------------------------------

	/**
	 * Validate Product per Google Rich Results requirements.
	 */
	private static function validate_product( $schema, $prefix, SchemaValidator $v ) {
		if ( empty( $schema['name'] ) ) {
			$v->add_error( "{$prefix}: Product missing required 'name'" );
		}

		if ( empty( $schema['image'] ) ) {
			$v->add_error( "{$prefix}: Product missing required 'image'" );
		}

		if ( empty( $schema['offers'] ) && empty( $schema['review'] ) && empty( $schema['aggregateRating'] ) ) {
			$v->add_error( "{$prefix}: Product must have 'offers', 'review', or 'aggregateRating' for rich results" );
		}

		if ( ! empty( $schema['offers'] ) ) {
			self::validate_product_offers( $schema['offers'], $prefix, $v );
		}

		if ( ! empty( $schema['aggregateRating'] ) ) {
			$v->validate_aggregate_rating( $schema['aggregateRating'], $prefix );
		}

		if ( ! empty( $schema['review'] ) && is_array( $schema['review'] ) ) {
			$reviews = isset( $schema['review']['@type'] ) ? [ $schema['review'] ] : $schema['review'];

			// Use a numeric counter (not the array key) so a reference object
			// like [ '@id' => '...#review' ] — which has string keys — does not
			// trigger a "string + int" TypeError. Skip non-array entries.
			$index = 0;
			foreach ( $reviews as $review ) {
				if ( ! is_array( $review ) ) {
					continue;
				}
				$v->validate_review_item( $review, $prefix, ++$index );
			}
		}

		if ( ! empty( $schema['brand'] ) && is_array( $schema['brand'] ) && empty( $schema['brand']['name'] ) ) {
			$v->add_warning( "{$prefix}: 'brand' should have a 'name' field" );
		}

		if ( empty( $schema['description'] ) ) {
			$v->add_warning( "{$prefix}: Product missing recommended 'description'" );
		}

		if ( empty( $schema['sku'] ) && empty( $schema['gtin'] ) && empty( $schema['gtin8'] )
			&& empty( $schema['gtin13'] ) && empty( $schema['gtin14'] ) && empty( $schema['mpn'] ) ) {
			$v->add_warning( "{$prefix}: Product missing identifier — 'sku', 'gtin', or 'mpn' is recommended" );
		}

		if ( empty( $schema['brand'] ) ) {
			$v->add_warning( "{$prefix}: Product missing recommended 'brand'" );
		}
	}

	/**
	 * Validate ProductGroup schema (variable product with hasVariant).
	 */
	private static function validate_productgroup( $schema, $prefix, SchemaValidator $v ) {
		if ( empty( $schema['name'] ) ) {
			$v->add_error( "{$prefix}: ProductGroup missing required 'name'" );
		}

		if ( empty( $schema['hasVariant'] ) || ! is_array( $schema['hasVariant'] ) ) {
			$v->add_error( "{$prefix}: ProductGroup missing required 'hasVariant' array" );
		} else {
			foreach ( $schema['hasVariant'] as $i => $variant ) {
				$vi = $i + 1;

				if ( empty( $variant['@type'] ) || 'Product' !== $variant['@type'] ) {
					$v->add_error( "{$prefix}: hasVariant[{$vi}] must have @type 'Product'" );
				}

				if ( empty( $variant['name'] ) ) {
					$v->add_warning( "{$prefix}: hasVariant[{$vi}] missing 'name'" );
				}

				if ( empty( $variant['offers'] ) ) {
					$v->add_warning( "{$prefix}: hasVariant[{$vi}] missing 'offers'" );
				}
			}
		}

		if ( empty( $schema['productGroupID'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'productGroupID'" );
		}

		if ( empty( $schema['variesBy'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'variesBy'" );
		}

		if ( empty( $schema['image'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'image'" );
		}

		if ( empty( $schema['description'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'description'" );
		}

		if ( empty( $schema['brand'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'brand'" );
		}
	}

	/**
	 * Validate Recipe per Google Rich Results requirements.
	 */
	private static function validate_recipe( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'recipeIngredient', 'recipeInstructions' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: Recipe missing required field '{$field}'" );
			}
		}

		foreach ( [ 'image', 'author', 'datePublished', 'totalTime', 'recipeYield' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_warning( "{$prefix}: Recipe missing recommended field '{$field}'" );
			}
		}
	}

	/**
	 * Validate Course per Google Rich Results requirements.
	 */
	private static function validate_course( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'description', 'provider' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: Course missing required field '{$field}'" );
			}
		}

		if ( ! empty( $schema['provider'] ) && is_array( $schema['provider'] ) ) {
			if ( empty( $schema['provider']['name'] ) && empty( $schema['provider']['@id'] ) ) {
				$v->add_warning( "{$prefix}: 'provider' should have a 'name' or '@id'" );
			}
		}
	}

	/**
	 * Validate LocalBusiness per Google Rich Results requirements.
	 */
	private static function validate_localbusiness( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'address' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: LocalBusiness missing required field '{$field}'" );
			}
		}

		if ( ! empty( $schema['address'] ) && is_array( $schema['address'] ) ) {
			foreach ( [ 'streetAddress', 'addressLocality', 'addressCountry' ] as $addr_field ) {
				if ( empty( $schema['address'][ $addr_field ] ) ) {
					$v->add_warning( "{$prefix}: 'address.{$addr_field}' is recommended" );
				}
			}
		}
	}

	/**
	 * Validate TouristAttraction required fields.
	 */
	private static function validate_touristattraction( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'image', 'description', 'address' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: TouristAttraction missing required field '{$field}'" );
			}
		}

		if ( empty( $schema['geo']['latitude'] ) ) {
			$v->add_error( "{$prefix}: TouristAttraction missing required field 'latitude'" );
		}

		if ( empty( $schema['geo']['longitude'] ) ) {
			$v->add_error( "{$prefix}: TouristAttraction missing required field 'longitude'" );
		}
	}

	/**
	 * Validate Product offers (single Offer, AggregateOffer, or array of either).
	 *
	 * @since 1.0.0
	 * @param array  $offers Offers data (single Offer, AggregateOffer, or array of Offers).
	 * @param string $prefix Error prefix.
	 * @return void
	 * @param SchemaValidator $v Validator collecting errors and warnings.
	 */
	private static function validate_product_offers( $offers, $prefix, SchemaValidator $v ) {
		$offer_type = $offers['@type'] ?? '';

		if ( 'AggregateOffer' === $offer_type ) {
			self::validate_aggregate_offer( $offers, $prefix, $v );
			return;
		}

		/** Single Offer object. */
		if ( 'Offer' === $offer_type ) {
			self::validate_single_offer( $offers, $prefix, 0, $v );
			return;
		}

		/** Array of Offer/AggregateOffer objects. */
		if ( isset( $offers[0] ) ) {
			foreach ( $offers as $i => $offer ) {
				$item_type = $offer['@type'] ?? '';

				if ( 'AggregateOffer' === $item_type ) {
					self::validate_aggregate_offer( $offer, $prefix, $v );
				} else {
					self::validate_single_offer( $offer, $prefix, $i, $v );
				}
			}
		}
	}

	/**
	 * Validate a single Offer object.
	 *
	 * Accepts price via top-level 'price' + 'priceCurrency' fields,
	 * or via 'priceSpecification' array of UnitPriceSpecification.
	 *
	 * @since 1.0.0
	 * @param array  $offer  Offer data.
	 * @param string $prefix Error prefix.
	 * @param int    $index  Offer index for messaging.
	 * @return void
	 * @param SchemaValidator $v Validator collecting errors and warnings.
	 */
	private static function validate_single_offer( $offer, $prefix, $index, SchemaValidator $v ) {
		$label              = $index > 0 ? "Offer #{$index}" : 'Offer';
		$has_price          = isset( $offer['price'] ) && '' !== $offer['price'];
		$has_price_spec     = ! empty( $offer['priceSpecification'] ) && is_array( $offer['priceSpecification'] );

		/** Price is required via top-level price or priceSpecification. */
		if ( ! $has_price && ! $has_price_spec ) {
			$v->add_error( "{$prefix}: {$label} missing required 'price' or 'priceSpecification'" );
		}

		/** priceCurrency is required when using top-level price (not needed if only in priceSpecification). */
		if ( $has_price && ! $has_price_spec && empty( $offer['priceCurrency'] ) ) {
			$v->add_error( "{$prefix}: {$label} missing required 'priceCurrency'" );
		}

		/** Validate each priceSpecification entry. */
		if ( $has_price_spec ) {
			$specs = self::normalize_price_specs( $offer['priceSpecification'] );
			foreach ( $specs as $si => $spec ) {
				if ( ! is_array( $spec ) ) {
					continue;
				}

				$sn = (int) $si + 1;

				if ( ! isset( $spec['price'] ) || '' === $spec['price'] ) {
					$v->add_error( "{$prefix}: {$label} priceSpecification #{$sn} missing 'price'" );
				}

				if ( empty( $spec['priceCurrency'] ) ) {
					$v->add_error( "{$prefix}: {$label} priceSpecification #{$sn} missing 'priceCurrency'" );
				}
			}
		}

		if ( empty( $offer['availability'] ) ) {
			$v->add_warning( "{$prefix}: {$label} missing recommended 'availability'" );
		} elseif ( ! self::is_schema_org_url( $v, $offer['availability'] ) ) {
			$v->add_warning( "{$prefix}: {$label} 'availability' should be a Schema.org URL (e.g. https://schema.org/InStock)" );
		}

		if ( empty( $offer['url'] ) ) {
			$v->add_warning( "{$prefix}: {$label} missing recommended 'url'" );
		}

		if ( ! empty( $offer['priceValidUntil'] ) && ! self::is_iso8601( $v, $offer['priceValidUntil'] ) ) {
			$v->add_warning( "{$prefix}: {$label} 'priceValidUntil' should be in ISO 8601 date format" );
		}

		if ( empty( $offer['hasMerchantReturnPolicy'] ) ) {
			$v->add_warning( "{$prefix}: {$label} missing recommended 'hasMerchantReturnPolicy'" );
		}

		if ( empty( $offer['shippingDetails'] ) ) {
			$v->add_warning( "{$prefix}: {$label} missing recommended 'shippingDetails'" );
		}
	}

	/**
	 * Validate an AggregateOffer object.
	 *
	 * @since 1.0.0
	 * @param array  $offer  AggregateOffer data.
	 * @param string $prefix Error prefix.
	 * @return void
	 * @param SchemaValidator $v Validator collecting errors and warnings.
	 */
	private static function validate_aggregate_offer( $offer, $prefix, SchemaValidator $v ) {
		if ( empty( $offer['lowPrice'] ) ) {
			$v->add_error( "{$prefix}: AggregateOffer missing required 'lowPrice'" );
		}

		if ( empty( $offer['priceCurrency'] ) ) {
			$v->add_error( "{$prefix}: AggregateOffer missing required 'priceCurrency'" );
		}

		if ( empty( $offer['highPrice'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer missing recommended 'highPrice'" );
		}

		if ( empty( $offer['offerCount'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer missing recommended 'offerCount'" );
		}

		if ( empty( $offer['availability'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer missing recommended 'availability'" );
		}

		if ( empty( $offer['url'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer missing recommended 'url'" );
		}

		if ( ! empty( $offer['priceValidUntil'] ) && ! self::is_iso8601( $v, $offer['priceValidUntil'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer 'priceValidUntil' should be in ISO 8601 date format" );
		}

		if ( empty( $offer['hasMerchantReturnPolicy'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer missing recommended 'hasMerchantReturnPolicy'" );
		}

		if ( empty( $offer['shippingDetails'] ) ) {
			$v->add_warning( "{$prefix}: AggregateOffer missing recommended 'shippingDetails'" );
		}

		/** Validate priceSpecification entries if present. */
		if ( ! empty( $offer['priceSpecification'] ) && is_array( $offer['priceSpecification'] ) ) {
			$specs = self::normalize_price_specs( $offer['priceSpecification'] );
			foreach ( $specs as $si => $spec ) {
				if ( ! is_array( $spec ) ) {
					continue;
				}

				$sn = (int) $si + 1;

				if ( ! isset( $spec['price'] ) || '' === $spec['price'] ) {
					$v->add_error( "{$prefix}: AggregateOffer priceSpecification #{$sn} missing 'price'" );
				}

				if ( empty( $spec['priceCurrency'] ) ) {
					$v->add_error( "{$prefix}: AggregateOffer priceSpecification #{$sn} missing 'priceCurrency'" );
				}
			}
		}
	}

	/**
	 * Normalize a priceSpecification value into a list of spec objects.
	 *
	 * Schema.org allows priceSpecification to be a single object or an array
	 * of objects. A single associative object (e.g. one UnitPriceSpecification)
	 * is wrapped in a one-element list so callers can iterate uniformly without
	 * mistaking the object's own keys for separate specifications.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $specs priceSpecification value (object or list of objects).
	 *
	 * @return array List of priceSpecification objects.
	 */
	private static function normalize_price_specs( $specs ) {
		if ( ! is_array( $specs ) ) {
			return [];
		}

		// A list has sequential integer keys (specs[0] exists); a single object
		// uses string keys like '@type'/'price'. Wrap a single object as a list.
		if ( ! isset( $specs[0] ) ) {
			return [ $specs ];
		}

		return $specs;
	}

	/**
	 * ISO 8601 date check via the free validator (public since free 3.1.4).
	 *
	 * Free 3.1.3 keeps the helper private; the same rule is applied inline then.
	 *
	 * @param SchemaValidator $v     Free validator.
	 * @param mixed           $value Value to check.
	 * @return bool
	 */
	private static function is_iso8601( $v, $value ) {
		if ( is_callable( [ $v, 'is_iso8601' ] ) ) {
			return $v->is_iso8601( $value );
		}

		return is_string( $value ) && (bool) preg_match( '/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2})?(\.\d+)?(Z|[+-]\d{2}:?\d{2})?)?$/', $value );
	}

	/**
	 * schema.org URL check via the free validator (public since free 3.1.4).
	 *
	 * @param SchemaValidator $v   Free validator.
	 * @param mixed           $url Value to check.
	 * @return bool
	 */
	private static function is_schema_org_url( $v, $url ) {
		if ( is_callable( [ $v, 'is_schema_org_url' ] ) ) {
			return $v->is_schema_org_url( $url );
		}

		return is_string( $url ) && (bool) preg_match( '/^https?:\/\/schema\.org\//', $url );
	}
}
